//: [Previous](@previous)

import Foundation


// HW1.1 Даны 2 целых числа в качестве аргументов функции. Сложить остатки от деления этих аргументов на 5 и вернуть результат.

func count(var1: Int, var2: Int) -> Int {
    let result = var1 % 5 + var2 % 5
    return result
}

count(var1: 12, var2: 13)

// HW 1.2 Даны 2 числа на вход функции. Первое - количество проголосовавших за патриотического кандидата ( Int ), второе - результат на выборах его в процентах (Double) ( сколько процентов от пришедших за него отдало голос ). Определить, сколько человек проголосовало на выборах.

func count1(amountCandidateVote: Int, resultProcent: Double) -> Int {
    let amountVote = Double(amountCandidateVote) / resultProcent * 100
    return Int(amountVote)
}

count1(amountCandidateVote: 27, resultProcent: 5.45)

// HW 1.3 Функция принимает на вход 3 аргумента - часы, минуты, секунды ( все Int ). Вернуть число секунд

func count3(hour: Int, minute: Int, second: Int) -> Int {
    
    let amountSeconds = (hour * 60 * 60) + (minute * 60) + second
    return amountSeconds
}

count3(hour: 3, minute: 20, second: 14)

// HW 1.4 Написать 2 функции. Обе принимают на вход 2 аргумента - длина и ширина прямоугольника. Но первая возвращает его периметр, вторая - площадь. Все в целых числах ( Int )

func perimeter(lenght: Int, width: Int) -> Int {
    let countPerimter = (lenght + width) * 2
    return countPerimter
}

perimeter(lenght: 5, width: 7)

func square(lenght: Int, width: Int) -> Int {
    let countSquare = lenght * width
    return countSquare
}

square(lenght: 5, width: 7)


// HW 1.5 Функция принимает на вход 2 аргумента. Первый - объем бутылки ( в долях от литра - 0.5, 0.7 и т д ), второй - крепость напитка ( десятичная дробь, все аргументы - Double). Вычислить количество выпитого чистого спирта в граммах ( миллилитры).

func countPureAlcohol(volume: Double, sturdiness: Double) -> Double {
    let pureAlcohol = volume * sturdiness * 10
    return pureAlcohol
}

countPureAlcohol(volume: 0.7, sturdiness: 40)

// HW 1.6 СЛОЖНА. Есть уравнение x2 + 3x - 44 = 0 Написать функцию, печатающую оба корня квадратного уравнения.Тут надо загуглить дискриминант и как корни уравнения вычислять. Используйте функцию sqrt() для вычисления квадратного корня. Коэффициенты квадратного уравнения ( множители перед x2, x и свободный член -44) передавайте в качестве аргументов в функцию.

func equat(a: Double, b: Double, c: Double) -> Double {
    let discriminant = (b*b) - (4*a*c)
    let x1 = (-b + sqrt(discriminant)) / (2*a)
    print("Первый квадратный корень равен \(x1)")
    let x2 = (-b - sqrt(discriminant)) / (2*a)
    print("Первый квадратный корень равен \(x2)")
    return discriminant
}

equat(a: 1, b: 3, c: -44)

// HW 1.7 СЛОЖНА. Написать функцию, принимающую в качестве аргументов длину катетов прямоугольного треугольника. Функция должна нарисовать в консоли треугольник из звёздочек таким образом ( загуглите циклы самостоятельно, можете забить, задача факультативная. Эт ежели хотите разобраться) :


func triangle(cath:Int){
    var star = ""
    for _ in 1...cath {
        star += "*"
        print(star)
    }
}

triangle(cath: 5)


// HW 1.8 Написать функцию, вычисляющую длину окружности. Радиус на вход в качестве аргумента ( Double ). На выходе - длина окружности. Число пи так писать Double.pi .

func circuitLenght(radius: Double) -> Double {
    return 2*Double.pi*radius
}

circuitLenght(radius: 5)

// HW 1.9 Написать функцию, принимающую на вход аргумент - длина стороны квадрата. Найти радиус вписанной окружности ( радиус вписанной в квадрат окружности - половина его стороны - нарисуйте и проверьте на бумажке) и вызвать функцию из п.8. Результат длины окружности вернуть из функции.

func radiusInsideRound(sideLenght: Double) -> Double{
    return circuitLenght(radius: sideLenght)/Double.pi/4
}
radiusInsideRound(sideLenght: 10)

// HW 1.10 Написать функцию, определяющую площадь круга по его радиусу ( то же, что в п.8, но площадь - загуглите формулу ) S=πr2

func squareRound(radius: Double) -> Double {
    return circuitLenght(radius: radius)*radius/2
}

squareRound(radius: 5)

// HW 1.11 Написать функцию, принимающую на вход объём бутылки, крепость напитка и количество бутылок, выпитых на вечеринке. Используя функцию из п. 5 определить суммарный объем выпитого. ( функцию из п.4 обязательно нужно вызвать)

func amountAlcohol(volume: Double, sturdiness: Double, bottleAmount: Double) -> Double {
    return countPureAlcohol(volume: volume, sturdiness: sturdiness)/sturdiness/10 * bottleAmount
}

amountAlcohol(volume: 0.7, sturdiness: 40, bottleAmount: 10)

//HW 1.12 И функцию, по стороне квадрата вычисляющую площадь вписанного круга ( аналогично п. 9 )

func squareRoundSide(radius: Double) -> Double {
    return Double.pi * radiusInsideRound(sideLenght: radius * 2) * radiusInsideRound(sideLenght: radius * 2)
}

squareRoundSide(radius: 5)

// HW 1.13 Используем встроенную sqrt(). Написать функцию, по двум катетам прямоугольного треугольника возвращающую гипотенузу ( теорему пифагора гугланите )

func triangle(cath1: Double, cath2: Double) -> Double {
    return sqrt(cath1*cath1 + cath2*cath2)
}

triangle(cath1: 10, cath2: 5)
